# First launch setup
1. Install the APK you build.
2. Open ONEX AI → Settings / Gemini API.
3. Tap Get Gemini API Key. Sign in and create a key if API access is available for your account.
4. Paste the key, keep the default model ID or enter a currently supported model ID, then Save Settings.
5. Tap Test API connection.
6. Return Home → Open AI Chat and ask a question.
7. For voice, tap Speak. Replies are spoken using the device's Android TTS voice; the voice can vary by device/language pack.

If the test returns an error, check the exact message, internet, API key, API access/quota, and model ID. A free API key does not guarantee unlimited usage or free access to every model.

# ONEX AI — Android starter project

This is a real Android source project starter, not a prebuilt APK. It includes:
- Dark purple ONEX UI
- Gemini API key/model settings and connection test
- Text chat through Gemini `generateContent`
- Android speech recognition and device TTS fallback
- YouTube open/search
- Camera capture (thumbnail) + Gemini image prompt
- Website Builder / Coding Agent / Reply Writer prompt modes

## Important limitations
- Gemini Live real-time natural voice is NOT integrated in this starter. The voice input uses Android speech recognition and spoken replies use Android Text-to-Speech. Live audio needs a separate compatible Gemini Live API integration and model access.
- This app does not silently control other apps, read all notifications, or auto-send messages.
- API keys stored on-device are not fully protected against a compromised/rooted device. For production, use a backend proxy.
- This project has not been compiled in your specific Termux environment. Do not assume the build will be error-free until you run it and test it.

## Build
See `BUILD_GUIDE.md`. Android SDK/platform/build-tools and a compatible JDK are required.


## Termux helper scripts
- `termux/setup_termux.sh`: installs general build tools and lists SDK package availability.
- `termux/build_onex.sh`: checks SDK API 35, runs the Gradle build, and copies the APK to Downloads if successful.
- These scripts cannot install an SDK that is unavailable for the device/repository.

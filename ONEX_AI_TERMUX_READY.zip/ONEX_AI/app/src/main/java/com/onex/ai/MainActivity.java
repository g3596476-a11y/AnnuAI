package com.onex.ai;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final String PREFS = "onex_settings";
    private SharedPreferences prefs;
    private LinearLayout root, messages;
    private EditText input;
    private TextView status;
    private TextToSpeech tts;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private String mode = "Assistant";
    private Bitmap pendingImage;
    private static final int SPEECH_REQUEST = 101;
    private static final int CAMERA_REQUEST = 102;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });
        showHome();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density); }

    private TextView label(String text, float size) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(0xFFF3F0FF);
        v.setPadding(dp(10), dp(8), dp(10), dp(8));
        return v;
    }

    private Button button(String text, Runnable action) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF6338C8));
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(8), dp(14), dp(8));
        return l;
    }

    private void setupBase(String title) {
        root = column();
        root.setBackgroundColor(0xFF090914);
        TextView heading = label("✦ ONEX AI  •  " + title, 22);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(heading);
        setContentView(root);
    }

    private void showHome() {
        setupBase("PERSONAL ASSISTANT");
        TextView intro = label("Your personal AI • Hindi / Hinglish\\nAsk, build, explore.", 15);
        root.addView(intro);
        root.addView(button("💬  Open AI Chat", this::showChat));
        root.addView(button("⚙️  Settings / Gemini API", this::showSettings));
        root.addView(button("▶  Open YouTube", () -> openAppOrSearch("com.google.android.youtube", "https://www.youtube.com")));
        root.addView(button("🔎  Search YouTube", () -> {
            EditText q = new EditText(this); q.setSingleLine(true); q.setHint("Song or video name");
            q.setTextColor(0xFFFFFFFF); q.setHintTextColor(0xFFAAA5BC);
            new android.app.AlertDialog.Builder(this).setTitle("YouTube search").setView(q)
                .setPositiveButton("Search", (d,w) -> {
                    String s = q.getText().toString().trim();
                    if (!s.isEmpty()) {
                        Intent i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com/results?search_query=" + android.net.Uri.encode(s)));
                        startActivity(i);
                    }
                }).setNegativeButton("Cancel", null).show();
        }));
        root.addView(button("📷  Camera Vision", this::takePhoto));
        root.addView(button("🌐  Website Builder Mode", () -> { mode = "Website Builder"; showChat(); addMessage("ONEX", "Website Builder mode selected. Describe the website you want."); }));
        root.addView(button("💻  Agentic Coding Mode", () -> { mode = "Coding Agent"; showChat(); addMessage("ONEX", "Coding Agent mode selected. Describe your project. Review generated code before running it."); }));
        root.addView(button("✉️  Draft a reply", () -> { mode = "Reply Writer"; showChat(); addMessage("ONEX", "Paste the message you received and I will draft a reply. Sending is left to you."); }));
        TextView note = label("Phone actions are limited by Android permissions and app restrictions. ONEX never silently sends messages.", 12);
        root.addView(note);
    }

    private void showSettings() {
        setupBase("SETTINGS");
        EditText key = new EditText(this);
        key.setSingleLine(true); key.setHint("Gemini API key"); key.setTextColor(0xFFFFFFFF);
        key.setHintTextColor(0xFFAAA5BC); key.setInputType(129);
        key.setText(prefs.getString("api_key", ""));
        root.addView(label("Gemini API Key", 15)); root.addView(key);
        EditText model = new EditText(this);
        model.setSingleLine(true); model.setHint("Model ID (e.g. gemini-2.5-flash)");
        model.setTextColor(0xFFFFFFFF); model.setHintTextColor(0xFFAAA5BC);
        model.setText(prefs.getString("model", "gemini-2.5-flash"));
        root.addView(label("Model ID", 15)); root.addView(model);
        root.addView(button("Save Settings", () -> {
            prefs.edit().putString("api_key", key.getText().toString().trim())
                .putString("model", model.getText().toString().trim().isEmpty() ? "gemini-2.5-flash" : model.getText().toString().trim()).apply();
            Toast.makeText(this, "Settings saved on this device", Toast.LENGTH_SHORT).show();
        }));
        root.addView(button("Get Gemini API Key (opens browser)", () -> {
            startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://aistudio.google.com/apikey")));
        }));
        root.addView(button("Test API connection", () -> {
            prefs.edit().putString("api_key", key.getText().toString().trim())
                .putString("model", model.getText().toString().trim()).apply();
            callGemini("Reply with exactly: ONEX connection successful.", null, answer -> {
                new android.app.AlertDialog.Builder(this).setTitle("API test").setMessage(answer)
                    .setPositiveButton("OK", null).show();
            });
        }));
        root.addView(button("Voice: Android speech recognition + TTS", () ->
            new android.app.AlertDialog.Builder(this).setTitle("Voice setup")
            .setMessage("This starter uses Android speech recognition and device text-to-speech as a fallback. Gemini Live natural voice requires a compatible Live API integration and model access; it is not enabled in this starter.")
            .setPositiveButton("OK", null).show()));
        root.addView(button("← Back Home", this::showHome));
        root.addView(label("Security: the key is stored in app preferences, not embedded in source. Direct-app keys can still be extracted from a compromised/rooted device. Do not share your key.", 12));
    }

    private void showChat() {
        setupBase(mode.toUpperCase());
        ScrollView scroll = new ScrollView(this);
        messages = column();
        scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        status = label("Ready", 12); root.addView(status);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        input = new EditText(this); input.setHint("Ask ONEX in Hindi / Hinglish…");
        input.setTextColor(0xFFFFFFFF); input.setHintTextColor(0xFFAAA5BC);
        row.addView(input, new LinearLayout.LayoutParams(0, -2, 1));
        Button send = button("Send", () -> sendInput());
        row.addView(send);
        root.addView(row);
        LinearLayout tools = new LinearLayout(this); tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.addView(button("🎙️ Speak", this::startSpeech), new LinearLayout.LayoutParams(0, -2, 1));
        tools.addView(button("📷 Image", this::takePhoto), new LinearLayout.LayoutParams(0, -2, 1));
        tools.addView(button("Home", this::showHome), new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(tools);
        addMessage("ONEX", "Namaste! Main ONEX hoon. Apna sawaal likho ya Speak dabao.");
    }

    private void addMessage(String who, String text) {
        if (messages == null) return;
        TextView v = label(who + "\\n" + text, 14);
        v.setBackgroundColor(who.equals("You") ? 0xFF25203B : 0xFF171629);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(4), 0, dp(4)); messages.addView(v, lp);
    }

    private void sendInput() {
        if (input == null) return;
        String text = input.getText().toString().trim();
        if (text.isEmpty() && pendingImage == null) return;
        input.setText("");
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(), 0);
        if (!text.isEmpty()) addMessage("You", text);
        String prompt = text;
        if (mode.equals("Website Builder")) prompt = "Act as a website builder. Provide complete, practical HTML/CSS/JavaScript code and setup steps for this request: " + text;
        else if (mode.equals("Coding Agent")) prompt = "Act as a careful coding agent. Plan first, provide files and code, explain tests and likely errors. Do not claim to have run code. Request: " + text;
        else if (mode.equals("Reply Writer")) prompt = "Draft a respectful, natural reply to this message. Do not send it. Message/context: " + text;
        Bitmap image = pendingImage; pendingImage = null;
        if (status != null) status.setText("Thinking…");
        callGemini(prompt, image, answer -> {
            addMessage("ONEX", answer);
            if (status != null) status.setText("Ready");
            if (tts != null && prefs.getBoolean("speak_replies", true)) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "onex_reply");
        });
    }

    private interface AnswerCallback { void done(String answer); }

    private void callGemini(String prompt, Bitmap image, AnswerCallback callback) {
        String key = prefs.getString("api_key", "").trim();
        String model = prefs.getString("model", "gemini-2.5-flash").trim();
        if (key.isEmpty()) { runOnUiThread(() -> callback.done("Pehle Settings mein Gemini API key save karo.")); return; }
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" +
                    android.net.Uri.encode(model).replace("%2F", "/") + ":generateContent?key=" + android.net.Uri.encode(key));
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(60000);
                conn.setDoOutput(true); conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                JSONObject partText = new JSONObject().put("text", prompt.isEmpty() ? "Describe this image." : prompt);
                JSONArray parts = new JSONArray().put(partText);
                if (image != null) {
                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    image.compress(Bitmap.CompressFormat.JPEG, 80, bytes);
                    String b64 = android.util.Base64.encodeToString(bytes.toByteArray(), android.util.Base64.NO_WRAP);
                    parts.put(new JSONObject().put("inline_data", new JSONObject().put("mime_type", "image/jpeg").put("data", b64)));
                }
                JSONObject body = new JSONObject().put("contents", new JSONArray().put(new JSONObject().put("parts", parts)));
                byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) { os.write(data); }
                int code = conn.getResponseCode();
                java.io.InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] buffer = new byte[4096]; int n;
                while ((n = stream.read(buffer)) > 0) out.write(buffer, 0, n);
                String response = new String(out.toByteArray(), StandardCharsets.UTF_8);
                JSONObject json = new JSONObject(response);
                String answer;
                if (code >= 200 && code < 300) {
                    answer = json.getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).optString("text", "No text returned.");
                } else {
                    JSONObject errObj = json.optJSONObject("error");
                    answer = "API error " + code + ": " + (errObj != null
                        ? errObj.optString("message", response) : response);
                }
                final String result = answer;
                runOnUiThread(() -> callback.done(result));
            } catch (Exception e) {
                runOnUiThread(() -> callback.done("Connection/API error: " + e.getMessage() +
                    "\\nCheck internet, model ID, API key and API quota."));
            } finally { if (conn != null) conn.disconnect(); }
        });
    }

    private void startSpeech() {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "ONEX ko bolkar batao");
            startActivityForResult(i, SPEECH_REQUEST);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Speech recognition app available nahi hai.", Toast.LENGTH_LONG).show();
        }
    }

    private void takePhoto() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 201); return;
        }
        try { startActivityForResult(new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE), CAMERA_REQUEST); }
        catch (Exception e) { Toast.makeText(this, "Camera app open nahi hua.", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == SPEECH_REQUEST) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                if (input != null) { input.setText(results.get(0)); sendInput(); }
                else { mode = "Assistant"; showChat(); input.setText(results.get(0)); sendInput(); }
            }
        } else if (requestCode == CAMERA_REQUEST) {
            Object obj = data.getExtras() != null ? data.getExtras().get("data") : null;
            if (obj instanceof Bitmap) {
                pendingImage = (Bitmap)obj;
                if (input == null) showChat();
                input.setText("Is image ko analyse karo aur Hindi mein samjhao.");
                Toast.makeText(this, "Image ready. Send dabao.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void openAppOrSearch(String packageName, String fallbackUrl) {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
            if (launch != null) startActivity(launch);
            else startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(fallbackUrl)));
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(fallbackUrl)));
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        executor.shutdownNow();
        super.onDestroy();
    }
}

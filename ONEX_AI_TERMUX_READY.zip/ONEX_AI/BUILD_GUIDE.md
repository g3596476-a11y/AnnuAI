# ONEX AI — Termux build guide

## Quick start
1. Download `ONEX_AI.zip` to your phone's Downloads folder.
2. Open Termux and run:

```bash
termux-setup-storage
cd ~/storage/downloads
unzip -o ONEX_AI.zip -d ~/
cd ~/ONEX_AI
bash termux/setup_termux.sh
```

3. Check whether your Termux repository offers a compatible Android SDK:

```bash
pkg search android-sdk
pkg search android-sdk-platform
pkg search android-sdk-build
```

4. If you have installed a compatible SDK with API 35, set its actual path (example only):

```bash
export ANDROID_HOME="$HOME/android-sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
```

Verify that this file exists:

```bash
ls "$ANDROID_HOME/platforms/android-35/android.jar"
```

5. Build:

```bash
cd ~/ONEX_AI
bash termux/build_onex.sh
```

If the build succeeds, the APK is copied to `~/storage/downloads/ONEX_AI.apk`.

## Important limitation
The project cannot bundle a complete, working Android SDK into the app ZIP. Termux package names and SDK availability depend on the repository and device architecture. Google's Android command-line tools may not run natively on every Android/Termux CPU architecture. The build script checks prerequisites and reports what's missing; it does not bypass missing SDK components.

If Termux cannot provide a compatible SDK, build the project in Android Studio or a compatible cloud Android build runner. Do not treat an APK as built until `app/build/outputs/apk/debug/app-debug.apk` actually exists.

## Common errors
- `Unable to locate package openjdk-17`: install `openjdk` instead, as the package name varies by repository.
- `SDK location not found`: set `ANDROID_HOME` and `ANDROID_SDK_ROOT` to the real SDK directory.
- `platform android-35 not found`: install Android SDK Platform 35.
- Gradle/JDK mismatch: the project uses Android Gradle Plugin 8.7.3; use a compatible JDK and Gradle wrapper.

#!/data/data/com.termux/files/usr/bin/bash
set -e
echo "ONEX AI Termux setup helper"
echo "This installs general build tools only; Android SDK availability depends on your Termux repository."
pkg update
pkg install openjdk gradle unzip zip git wget -y
echo
echo "Java:"
java -version
echo
echo "Gradle:"
gradle --version
echo
echo "Searching Android SDK packages available in your repo..."
pkg search android-sdk || true
pkg search android-sdk-platform || true
pkg search android-sdk-build || true
echo
echo "If a compatible Android SDK API 35 is available, install it using the exact package names shown above."
echo "Then run: bash termux/build_onex.sh"

#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "======================================"
echo "       ONEX AI - Termux Builder"
echo "======================================"

if ! command -v pkg >/dev/null 2>&1; then
  echo "ERROR: Ye script Termux ke andar run karo."
  exit 1
fi

echo
echo "[1/5] Installing available build tools..."
pkg update
pkg install openjdk gradle unzip zip git wget -y

echo
echo "[2/5] Checking Java..."
if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java install nahi hua. Run: pkg search openjdk"
  exit 1
fi
java -version

echo
echo "[3/5] Checking Android SDK..."
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK" ]; then
  for candidate in "$HOME/android-sdk" "$PREFIX/share/android-sdk" "$PREFIX/opt/android-sdk"; do
    if [ -d "$candidate" ]; then SDK="$candidate"; break; fi
  done
fi

if [ -z "$SDK" ] || [ ! -f "$SDK/platforms/android-35/android.jar" ]; then
  echo
  echo "ANDROID SDK API 35 nahi mila."
  echo "Termux ke package names/repositories alag ho sakte hain."
  echo "Try these commands and inspect available package names:"
  echo "  pkg search android-sdk"
  echo "  pkg search android-sdk-platform"
  echo "  pkg search android-sdk-build"
  echo
  echo "SDK install hone ke baad actual SDK path set karo, example:"
  echo "  export ANDROID_HOME=\$HOME/android-sdk"
  echo "  export ANDROID_SDK_ROOT=\$ANDROID_HOME"
  echo "Then rerun: bash termux/build_onex.sh"
  echo
  echo "Note: Android command-line SDK tools may not run natively on every Android/Termux CPU architecture."
  exit 2
fi

export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
echo "SDK found: $SDK"

echo
echo "[4/5] Creating Gradle wrapper if missing..."
if [ ! -f ./gradlew ]; then
  gradle wrapper --gradle-version 8.9
fi
chmod +x ./gradlew

echo
echo "[5/5] Building debug APK..."
./gradlew assembleDebug

APK="app/build/outputs/apk/debug/app-debug.apk"
if [ ! -f "$APK" ]; then
  echo "ERROR: Build command completed but APK not found at $APK"
  exit 3
fi

mkdir -p "$HOME/storage/downloads"
cp "$APK" "$HOME/storage/downloads/ONEX_AI.apk"
echo
echo "SUCCESS! APK copied to:"
echo "$HOME/storage/downloads/ONEX_AI.apk"
